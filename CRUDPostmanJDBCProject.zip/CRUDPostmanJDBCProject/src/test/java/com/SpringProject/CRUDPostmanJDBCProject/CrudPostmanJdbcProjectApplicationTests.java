package com.SpringProject.CRUDPostmanJDBCProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudPostmanJdbcProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
