package com.SpringProject.CRUDPostmanJDBCProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPostmanJdbcProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPostmanJdbcProjectApplication.class, args);
	}

}
